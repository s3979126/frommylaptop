# RMIT University Vietnam
# Course: COSC2429 Introduction to Programming
# Semester: 2022C
# Assignment: 2
# Author: HoangThoAnh(s3979126)
# Created date: 17/12/2022
# Last modified date: 17/12/2022

times=1
def recur_representative(n):
    """
    :param n:
    :return:
    """
    global times
    if n ==1:
        times+=n
        return times
    times = n + recur_representative(n-1)
    return times
#main
students=int(input("Enter the number of students:"))
print("Therse are",recur_representative(students),"way(s) to select a representative board from ", students," students. ")